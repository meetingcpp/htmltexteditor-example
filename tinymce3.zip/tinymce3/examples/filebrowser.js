function myFileBrowser(field_name, url, type, win)
{
window.hostObject.selectImage();
return false;
}
(function() {
	tinymce.create('tinymce.plugins.QtImagePlugin', {
		init : function(ed, url) {
			// Register the command so that it can be invoked by using tinyMCE.activeEditor.execCommand('mceExample');
			ed.addCommand('mceQtImage', function() {
      window.hostObject.selectImage();
			});
			// Register example button
			ed.addButton('qtimage', {
				title : 'qtimage.desc',
				cmd : 'mceQtImage',
				image : url + '/img/image.gif'
			});
			// Add a node change handler, selects the button in the UI when a image is selected
			ed.onNodeChange.add(function(ed, cm, n) {
				cm.setActive('qtimage', n.nodeName == 'IMG');
			});
		},
		createControl : function(n, cm){return null;},
		getInfo : function() {
			return {
				longname : 'Qt Image Plugin',
				author : 'Jens Weller',
				authorurl : 'http://meetingcpp.com',
				infourl : 'http://meetingcpp.com',
				version : "1.0"
			};
		}
	});
	// Register plugin
	tinymce.PluginManager.add('qtimage', tinymce.plugins.QtImagePlugin);
})();
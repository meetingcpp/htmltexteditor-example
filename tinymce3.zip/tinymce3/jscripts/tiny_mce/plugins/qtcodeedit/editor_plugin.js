(function() {
	tinymce.create('tinymce.plugins.QtCodeEditPlugin', {
		init : function(ed, url) {
			// Register the command so that it can be invoked by using tinyMCE.activeEditor.execCommand('mceExample');
			ed.addCommand('mceQtCodeEdit', function() {
      window.hostObject.showHTML(tinyMCE.activeEditor.getContent());
			});
			// Register example button
      ed.addButton('code', {
				title : 'show html',
				cmd : 'mceQtCodeEdit'
			});
		},
		createControl : function(n, cm){return null;},
		getInfo : function() {
			return {
				longname : 'Qt Code Edit Plugin',
				author : 'Jens Weller',
				authorurl : 'http://meetingcpp.com',
				infourl : 'http://meetingcpp.com',
				version : "1.0"
			};
		}
	});
	// Register plugin
	tinymce.PluginManager.add('qtcodeedit', tinymce.plugins.QtCodeEditPlugin);
})();
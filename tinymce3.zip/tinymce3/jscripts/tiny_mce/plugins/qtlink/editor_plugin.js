(function() {
	tinymce.create('tinymce.plugins.QtLinkPlugin', {
		init : function(ed, url) {
			// Register the command so that it can be invoked by using tinyMCE.activeEditor.execCommand('mceExample');
			ed.addCommand('mceQtLink', function() {
      var se = ed.selection;
			// No selection and not in link
			if (se.isCollapsed() && !ed.dom.getParent(se.getNode(), 'A'))
				return;
      window.hostObject.insertLink();
			});
			// Register example button
			
      ed.addButton('link', {
				title : 'insert link',
				cmd : 'mceQtLink'
			});
			// Add a node change handler, selects the button in the UI when a image is selected
			ed.onNodeChange.add(function(ed, cm, n) {
				cm.setActive('qtlink', n.nodeName == 'A');
			});
		},
		createControl : function(n, cm){return null;},
		getInfo : function() {
			return {
				longname : 'Qt Link Plugin',
				author : 'Jens Weller',
				authorurl : 'http://meetingcpp.com',
				infourl : 'http://meetingcpp.com',
				version : "1.0"
			};
		}
	});
	// Register plugin
	tinymce.PluginManager.add('qtlink', tinymce.plugins.QtLinkPlugin);
})();